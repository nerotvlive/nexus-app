function initDashboard() {

}